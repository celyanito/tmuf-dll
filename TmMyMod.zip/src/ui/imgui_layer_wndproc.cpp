#include "../../include/ui/imgui_layer.h"

#include "../../external/imgui/imgui.h"
#include "../../external/imgui/backends/imgui_impl_win32.h"

namespace ui
{
    bool HandleWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        return ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam) != 0;
    }
}
